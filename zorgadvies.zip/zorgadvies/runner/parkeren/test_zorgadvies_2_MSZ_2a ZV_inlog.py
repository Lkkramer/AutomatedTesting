import re
from playwright.sync_api import Page, expect


def test_example(page: Page) -> None:
    page.goto("https://www2.tst.menzis.nl/mijn/zorgadvies/zoekzorgaanbieder_MSZ")
    page.get_by_role("button", name="Accepteren").click()
    page.get_by_role("button", name="Loginstub", exact=True).click()
    page.get_by_placeholder("BSN").click()
    page.get_by_placeholder("BSN").fill("628469766")
    page.get_by_role("button", name="Verzekerdennummer").dblclick()
    page.goto("https://www2.tst.menzis.nl/mijn/zorgadvies/zoekzorgaanbieder_MSZ")
    import time
    time.sleep(1)
    page.get_by_label("E-mail").click()
    page.get_by_label("E-mail").fill("bremer.an@menzis.nl")
    page.get_by_label("Telefoonnummer").click()
    import time
    time.sleep(2)
    page.get_by_label("Telefoonnummer").fill("0612345678")
    page.get_by_role("button", name="Volgende").click()
    import time
    time.sleep(2)
    page.locator("#Geboortedatum_Value_Day").click()
    page.locator("#Geboortedatum_Value_Day").fill("01")
    page.locator("#Geboortedatum_Value_Month").fill("01")
    page.locator("#Geboortedatum_Value_Year").fill("1970")
    import time
    time.sleep(2)
    page.locator("label").filter(has_text="Specialist").locator("span").first.click()
    page.get_by_label("Naar welk specialisme/").select_option("Chirurg")
    import time
    time.sleep(2)
    page.get_by_placeholder("Beschrijf kort uw diagnose").click()
    page.get_by_placeholder("Beschrijf kort uw diagnose").fill("test")
    import time
    time.sleep(2)
    page.get_by_placeholder("Beschrijf kort uw klachten").click()
    page.get_by_placeholder("Beschrijf kort uw klachten").fill("test")
    import time
    time.sleep(2)
    # page.get_by_placeholder("Uw zorgaanbieder").click()
    page.get_by_placeholder("Uw zorgaanbieder").fill("test")
    page.get_by_placeholder("Maximale afstand in kilometers").click()
    page.get_by_placeholder("Maximale afstand in kilometers").fill("50")
    import time
    time.sleep(2)
    page.get_by_placeholder("Maximale afstand in kilometers").click()
    page.get_by_placeholder("Maximale afstand in kilometers").fill("50")
    page.get_by_role("button", name="verstuur").click()
    import time
    time.sleep (2)
    page.get_by_label("Knop gebruikers menu").click()
    page.get_by_role("link", name="Uitloggen").click()
