import re
from playwright.sync_api import Page, expect


def test_example(page: Page) -> None:
    page.goto("https://www2.tst.menzis.nl/zorgadvies")
    page.get_by_role("button", name="Accepteren").click()
    page.get_by_label("Waar gaat uw vraag over?").first.click()
    # page.get_by_label("Over welke soort zorg heeft u").click()
    page.get_by_label("Waar gaat uw vraag over?").select_option("MSZ")
    import time
    time.sleep(2)
    page.get_by_label("Waarmee kunnen we u helpen?").select_option("Ik zoek een zorgaanbieder")
    page.get_by_label("Waarmee kunnen we u helpen?").select_option("Ik zoek een zorgaanbieder")
    import time
    time.sleep(2)




