import re
from playwright.sync_api import Page, expect


def test_example(page: Page) -> None:
    page.goto("https://www2.tst.menzis.nl/zorgadvies/intake")
    page.get_by_role("button", name="Accepteren").click()
    page.get_by_label("Waar gaat uw vraag over?").first.click()
    import time
    time.sleep(4)
    page.get_by_label("Waar gaat uw vraag over?").select_option("Huisartsenzorg")
    import time
    time.sleep(4)
    page.get_by_label("Waarmee kunnen we u helpen?").select_option("Ik heb hulp nodig bij het vinden van een huisarts in een probleemgebied")
    # page.get_by_label("Waarmee kunnen we u helpen?").select_option("Ik wil graag een kortere wachttijd")
    import time
    time.sleep(10)
    page.get_by_role("button", name="Doorgaan").click()
    page.locator("label").filter(has_text="nee").locator("span").first.click()
    import time
    time.sleep(10)
    page.goto("https://www2.tst.menzis.nl/zorgadvies")
    page.get_by_role("button", name="Doorgaan").click()
    page.locator("label").filter(has_text="ja").locator("span").first.click()
    ## to do controleer tekstmelding
    page.get_by_text("Diagnostisch onderzoek").click()
    import time
    time.sleep(10)
    page.get_by_placeholder("aantal weken").click()
    page.get_by_placeholder("aantal weken").fill("2")
    page.get_by_placeholder("aantal weken").press("Enter")
    ## to do controleer tektmelding
    import time
    time.sleep(10)
    page.goto("https://www2.tst.menzis.nl/zorgadvies")
    page.get_by_role("button", name="Doorgaan").click()
    page.get_by_placeholder("aantal weken").click()
    page.get_by_placeholder("aantal weken").fill("50")
    page.get_by_placeholder("aantal weken").press("Enter")
    page.get_by_role("link", name="Log in en ga door").click()   
    import time
    time.sleep(10)